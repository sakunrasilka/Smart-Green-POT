# smart green pot > 2024-09-12 2:03pm
https://universe.roboflow.com/sakun/smart-green-pot

Provided by a Roboflow user
License: CC BY 4.0

